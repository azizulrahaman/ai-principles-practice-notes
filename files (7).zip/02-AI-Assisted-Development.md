# Assignment 02 — AI-Assisted Software Development

**Course:** Artificial Intelligence: Principles and Practice  
**Student:** Md Azizul Rahaman | Touro University | Fall 2025

---

## Project Overview

| Detail | Info |
|--------|------|
| **Project** | Recipe Management System with Nutritional Analysis |
| **AI Tool Used** | Claude (Anthropic AI) |
| **Final Code** | 312 lines of Python |

---

## Executive Summary

This report documents the development of a Recipe Management System using AI-assisted programming with Claude. The project demonstrates AI tools in software development through a **three-iteration process**.

### Key Results
- 312-line Python application with recipe management, nutritional analysis, meal planning, and data visualization
- Estimated **70% reduction in development time** (40 hours → 12 hours)
- AI required significant human guidance for architectural decisions and UX design

---

## What I Provided to the AI Tool

**Initial Prompt:**
> "I need help creating a Python program for a recipe management system. The program should allow users to add, edit, and delete recipes, track ingredients with quantities and units, calculate nutritional information automatically, provide meal planning functionality, include recipe search and filtering, generate shopping lists from meal plans, and have a user-friendly command-line interface."

---

## Iteration Results

### Iteration 1 — Initial Response
- **Output:** 180 lines of basic Python code
- **Features:** Recipe, Ingredient, and RecipeManager classes; basic CRUD operations; JSON persistence; simple CLI menu

### Iteration 2 — Refinement
- Added nutritional API integration
- Improved error handling and input validation

### Iteration 3 — Final Version
- Full meal planning functionality
- Data visualization capabilities
- Complete 312-line professional application

---

## Key Findings

| Finding | Detail |
|---------|--------|
| AI strengths | Code generation, structure, implementing complex features |
| AI limitations | Architectural decisions, feature completeness, UX design |
| Best practice | Iterative refinement with specific requirement articulation |

---

## Conclusion

Successful AI-assisted development depends on **iterative refinement**, **specific requirement articulation**, and **human expertise** in domain logic and quality standards. AI tools can accelerate programming tasks while maintaining high code quality when guided effectively.
