# Assignment 07 — AI Challenges, Risks & Regulatory Responses

**Course:** Artificial Intelligence: Principles and Practice  
**Instructor:** Prof. Behrooz Khorsandi  
**Student:** Md Azizul Rahaman | Touro University

---

## Challenge 1: Bias Can Affect Results

AI systems produce biased outcomes when trained on data reflecting historical prejudices or lacking diverse representation — affecting loan approvals, hiring algorithms, and facial recognition systems.

### Government Actions
| Regulation | Key Requirement |
|-----------|----------------|
| **Colorado AI Act (May 2024)** | First U.S. state law; requires reasonable care to prevent discrimination; mandates disclosure |
| **EU AI Act (August 2024)** | Risk-based framework; bias testing required for high-risk AI in hiring, credit, law enforcement |
| **AI Civil Rights Act (2024)** | Pre-deployment evaluations; post-deployment impact assessments; FTC enforcement |

### Company Actions
- Regular algorithmic audits using **SHAP** (Shapley Additive Explanations)
- Diverse and representative training datasets
- AI ethics boards overseeing development
- A major European bank reduced credit decision disputes by **30%** after implementing explainable AI

---

## Challenge 2: Errors Can Cause Harm

AI errors in safety-critical applications (autonomous vehicles, medical diagnostics, industrial systems) can be **systematic**, affecting thousands of decisions simultaneously.

### Government Actions
- **NHTSA AV TEST Initiative:** Voluntary testing information submission for autonomous vehicles
- **USDOT (2025):** New automated vehicle framework with updated Standing General Orders
- **NHTSA data (June 2024–March 2025):** 570 crashes involving automated driving systems
- **California:** 761 AV incidents reported; CPUC maintains permit authority

### Company Actions
- **Waymo:** 57% reduction in police-reported crashes vs. human drivers
- **Volvo:** Accepts full liability for crashes in autonomous mode
- **Mayo Clinic:** Explainable diagnostics AI reduced physician override rates from **31% to 12%** while improving accuracy by **17%**
- Human-in-the-loop models — AI recommendations require physician approval

---

## Challenge 3: Data Could Be Exposed

AI systems require massive amounts of data, creating significant privacy and security risks — especially in healthcare, finance, and language models.

### Government Actions
| Regulation | Action |
|-----------|--------|
| **GDPR** | Global benchmark; Italy fined OpenAI **€15 million** for ChatGPT data practices (Dec 2024) |
| **U.S. State Laws (2024)** | Record year — 9 new states enacted privacy laws; 21 total active |
| **CCPA/CPRA** | Addresses automated decision-making; right to question profiling |
| **EU AI Act** | Mandates privacy-by-design; disclosure when interacting with AI |

### Company Actions
- **Privacy-Enhancing Technologies (PETs):** Differential privacy, federated learning, secure multi-party computation
- **DRIC (Data Remains In Car):** Automobile manufacturers processing data locally
- Mandatory **Data Protection Impact Assessments (DPIAs)** before AI deployment
- Third-party vendor compliance audits with breach notification mechanisms

---

## Challenge 4: Solutions May Not Work for Everyone

AI systems often fail to accommodate diverse users — approximately **1.3 billion people** globally are excluded from fully participating in the digital economy due to inaccessible AI.

**Examples of exclusion:**
- Home automation without audio excludes visually impaired users
- Speech recognition trained on standard accents fails for accent diversity
- Complex interfaces inaccessible to users with cognitive disabilities

### Government Actions
| Regulation | Requirement |
|-----------|------------|
| **U.S. DOJ (April 2024)** | State/local government websites must meet **WCAG 2.1 Level AA**; deadline April 24, 2026 |
| **European Accessibility Act (June 2025)** | Websites, mobile apps, e-commerce must meet EN 301 549 standard |
| **WCAG 3.0** | Holistic accessibility beyond web; individual adaptation focus |

### Company Actions
- Universal design principles embedded from development start
- Multi-language and multi-accent model training
- Accessibility testing with diverse user groups
- Screen reader compatibility and alternative input methods

---

## Summary

| Challenge | Core Issue | Key Response |
|-----------|-----------|-------------|
| Bias | Discriminatory outcomes | Algorithmic audits, EU AI Act |
| Errors | Safety-critical failures | NHTSA oversight, human-in-loop |
| Data Exposure | Privacy breaches | GDPR, PETs, DPIAs |
| Accessibility | Digital exclusion | WCAG standards, EAA |
