# Assignment 08 — GDPR & CCPA: Impacts on AI

**Course:** Artificial Intelligence: Principles and Practice  
**Student:** Md Azizul Rahaman | Touro University

---

## Part 1: What GDPR Does With Respect to AI

The **General Data Protection Regulation (GDPR)**, effective May 25, 2018, is the most influential data protection law globally and has profoundly shaped AI development across the EU and worldwide.

### GDPR's 4 Critical Actions on AI

| Action | Description |
|--------|-------------|
| **1. Controls training data** | What personal data can be used for AI training |
| **2. Grants individual rights** | Powerful rights regarding AI systems processing their data |
| **3. Requires transparency** | AI systems must be explainable and non-discriminatory |
| **4. Imposes penalties** | Up to €20M or 4% of annual global revenue |

---

### Controlling Data for AI Training

- **Article 4** defines personal data as any info relating to an identifiable person — significant because AI can re-identify seemingly anonymized data
- Organizations must establish one of **6 lawful bases** before processing data for AI training: consent, contract, legal obligation, vital interests, public task, or legitimate interest
- **EDPB Opinion 28/2024:** Organizations using legitimate interest must conduct a 3-step assessment:
  1. Identify the legitimate interest
  2. Demonstrate processing is necessary
  3. Balance test — organization's interests must not override individual rights

---

### Individual Rights Regarding AI Systems

| Right | Impact on AI |
|-------|-------------|
| **Right to Know** | Must disclose AI systems processing data, logic involved, consequences |
| **Right to Object** | Individuals can request organizations stop using their data for AI |
| **Right to Human Review** | Consequential AI decisions (hiring, lending, healthcare) must allow human review |
| **Right to be Forgotten** | Technically extremely difficult — data embedded in model weights |

---

### Preventing AI Discrimination

- **Article 35** requires **Data Protection Impact Assessments (DPIAs)** before deploying high-risk AI
- DPIAs force organizations to assess:
  - Discrimination against protected groups
  - Inappropriate denial of services
  - Processing of special category data (race, health, sexual orientation)
- Organizations have discovered systematic discrimination through DPIAs in hiring, lending, and insurance

---

### Real-World GDPR Enforcement

| Case | Action |
|------|--------|
| **X (Twitter) / Grok AI** | Irish DPC forced suspension of AI training (May 2024) |
| **Clearview AI** | €50M+ fines across EU for biometric data collection |
| **OpenAI / ChatGPT** | Italy fined €15M for data collection practices (Dec 2024) |

---

## Part 2: What CCPA Does With Respect to AI

The **California Consumer Privacy Act (CCPA)**, effective January 1, 2020, was the first comprehensive U.S. state privacy law. Enhanced by the **CPRA (2020)**, it now explicitly addresses AI through Automated Decision-Making Technology (ADMT) regulations.

### CCPA's 5 Critical Actions on AI

1. Recognizes AI systems as personal data repositories
2. Imposes transparency requirements on AI developers
3. Grants consumers rights regarding automated decisions
4. Requires discrimination assessment and mitigation
5. Imposes significant penalties for violations

---

### Recognizing AI as Personal Data (AB 1008, Jan 2025)

- Expanded CCPA definition to include **AI systems capable of outputting personal information**
- A trained AI model itself is now treated as a repository of personal information
- **SB 1223 (Neural Data):** Classifies brain activity data as sensitive personal information

---

### ADMT Regulations (Effective January 1, 2026)

The most stringent AI requirements in the United States:

| Requirement | Detail |
|-------------|--------|
| **Pre-use Notice** | Explain how ADMT works and consumer rights |
| **Risk Assessments** | Document benefits and negative impacts including discrimination |
| **Opt-out Rights** | Consumers can opt out of significant automated decisions |
| **Access Rights** | Consumers can understand decisions affecting them |

**Covered decisions:** Financial services, lending, housing, insurance, education, employment, healthcare

---

### Transparency Requirements

| Law | Requirement |
|-----|-------------|
| **AB 2013 (Jan 2026)** | Generative AI developers with 1M+ monthly users must disclose training data sources |
| **SB 942 (Jan 2025)** | AI content detection methods required; users can verify if content is AI-generated |

---

### CCPA Penalties

- **$2,500** per unintentional violation per consumer
- **$7,500** per intentional violation per consumer
- A single violation affecting **10,000 consumers** = **$25M–$75M** in penalties

---

## Other Major AI Regulations

| Regulation | Key Feature |
|-----------|------------|
| **EU AI Act (Aug 2024)** | World's first comprehensive AI law; risk-based classification (unacceptable/high/limited/minimal) |
| **Colorado AI Act (Feb 2026)** | First U.S. state comprehensive AI law; NIST AI RMF alignment required |

---

## GDPR vs. CCPA Comparison

| Feature | GDPR | CCPA/CPRA |
|---------|------|-----------|
| **Scope** | EU residents globally | California residents |
| **Effective** | May 2018 | January 2020 |
| **AI Training Control** | Strict lawful basis required | Expanding through amendments |
| **Individual Rights** | Comprehensive (access, deletion, portability, object) | Similar rights with California focus |
| **Penalties** | €20M or 4% global revenue | $2,500–$7,500 per violation per consumer |
| **Global Influence** | Inspired LGPD, APPI, PIPA, CCPA | Influencing other U.S. state laws |

---

## Conclusion

Both GDPR and CCPA significantly constrain how AI systems can collect data, make decisions, and process personal information. Together they represent the current global standard for AI governance — organizations must design AI systems with privacy, transparency, and fairness built in from the start.
